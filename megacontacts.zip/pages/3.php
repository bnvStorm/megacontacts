<!DOCTYPE html>
<html lang="ru">
<?php include '../includes/head.php'; ?>
<title>4920</title>
<!-- <meta name="description" content="О компании Промотход Сервис - лидера на рынке контейнерных площадок для бизнеса"> -->
<meta name="robots" content="index,follow">
<link rel="canonical" href="https://rpo.kz/about"/>
</head>
<body>
<div class="body-wrapper">
<?php include '../includes/navbar.php'; ?>
  <!--/.navbar -->
  <div id="home" class="section">
    <div class="light-wrapper">
      <div class="fullscreenbanner-container revolution" style="height:1vh;">

        <!-- /.fullscreenbanner -->
      </div>
      <!-- /.fullscreenbanner-container -->
    </div>
  </div>


     <div id="about" class="section anchor">
    <div class="light-wrapper">
      <div class="container inner">
	<div class="page" style="text-align:center;">

<img src="../img/post.jpg" alt="">

	</div>
</div>
</div>
</div>
<!-- /#about -->
<!-- /#contact -->
<?php include '../includes/footer.php'; ?>
</body>
</html>
