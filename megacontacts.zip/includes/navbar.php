  <div class="navbar default">
    <div class="navbar-header">
      <div class="container">
        <!-- <div class="basic-wrapper"> <a class="btn responsive-menu pull-right" data-toggle="collapse" data-target=".navbar-collapse"><i class='icon-menu-1'></i></a> <a class="navbar-brand parallelogram" href="../"><img src="../style/images/logo.png" alt="" data-src="../style/images/logo.png" data-ret="../style/images/logo@2x.png" class="retina" /></a> </div> -->
        <nav class="collapse navbar-collapse pull-right">
          <ul class="nav navbar-nav">
            <li><a href="/">Главная</a></li>
            <!-- <li><a href="#services">Services</a></li>
            <li><a href="#portfolio">Portfolio</a></li> -->
            <li><a href="../pages/4">Как заключить договор с компанией</a></li>
            <li><a href="../pages/2">Об электронном документе и ЭЦП</a></li>
            <li><a href="../pages/3">О выставлении АВР в электронном виде</a></li>
            <li><a href="../pages/1">Инструкция для контрагентов</a></li>
<!--  по переводу документооборота в электронно-цифровой формат
            <li class="dropdown"><a href="#" class="dropdown-toggle js-activated">Features</a>
              <ul class="dropdown-menu">
                <li class="dropdown-submenu"><a href="#">Blog</a>
                  <ul class="dropdown-menu">
                    <li><a href="blog.html">Medium Image Layout</a></li>
                    <li><a href="blog2.html">Grid Blog</a></li>
                    <li><a href="blog3.html">Grid Blog with Sidebar</a></li>
                    <li><a href="blog4.html">Classic Blog</a></li>
                    <li><a href="blog-post.html">Blog Post</a></li>
                  </ul>
                </li>
            </li> -->
          </ul>
        </nav>
      </div>
    </div>
    <!--/.nav-collapse -->
  </div>
