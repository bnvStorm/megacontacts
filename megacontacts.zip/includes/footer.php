  <footer class="footer">
    <div class="container inner">
      <!-- <p class="pull-left">© 2020 ТОО "Промотход Сервис".</p>
      <ul class="social pull-right">
        <li><a href="tel:+77057657788">+7 705 765 7788</a></li>
        <li><a target="_blank" href="#"><img style="width:30px;" src="../style/images/icon/winst.png" alt=""></a></li>
        <li><a target="_blank" href="#"><img style="width:30px;" src="../style/images/icon/wface.png" alt=""></a></li>
        <li><a target="_blank" href="#"><img style="width:30px;" src="../style/images/icon/wok.png" alt=""></a></li>
      </ul> -->
    </div>
    <!-- .container -->
  </footer>
  <!-- /footer -->
</div>
<!-- .body-wrapper -->
<!-- Bootstrap core CSS -->
<link href="https://rpo.kz/style/css/bootstrap.css" rel="stylesheet">
<link href="https://rpo.kz/style/css/settings.css" rel="stylesheet">
<link href="https://rpo.kz/style/css/owl.carousel.css" rel="stylesheet">
<link href="https://rpo.kz/style/js/google-code-prettify/prettify.css" rel="stylesheet">
<!-- <link href="https://rpo.kz/style/js/fancybox/jquery.fancybox.css" rel="stylesheet" type="text/css" media="all" />
<link href="https://rpo.kz/style/js/fancybox/helpers/jquery.fancybox-thumbs.css?v=1.0.2" rel="stylesheet" type="text/css" /> -->
<link href="https://rpo.kz/style.css" rel="stylesheet">
<!-- <link href="https://rpo.kz/style/css/color/blue.css" rel="stylesheet"> -->
<link href="https://rpo.kz/style/type/budicons.css" rel="stylesheet">
<link href="../../style/css/site.addons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
<script src="https://rpo.kz/style/js/jquery.min.js"></script>
<script src="https://rpo.kz/style/js/bootstrap.min.js"></script>
<script src="https://rpo.kz/style/js/twitter-bootstrap-hover-dropdown.min.js"></script>
<script src="https://rpo.kz/style/js/jquery.themepunch.plugins.min.js"></script>
<script src="https://rpo.kz/style/js/jquery.themepunch.revolution.min.js"></script>
<script src="https://rpo.kz/style/js/jquery.easytabs.min.js"></script>
<script src="https://rpo.kz/style/js/owl.carousel.min.js"></script>
<script src="https://rpo.kz/style/js/jquery.isotope.min.js"></script>
<script src="https://rpo.kz/style/js/jquery.fitvids.js"></script>
<script src="https://rpo.kz/style/js/jquery.fancybox.pack.js"></script>
<!-- <script src="https://rpo.kz/style/js/fancybox/helpers/jquery.fancybox-thumbs.js?v=1.0.2"></script>
<script src="https://rpo.kz/style/js/fancybox/helpers/jquery.fancybox-media.js?v=1.0.0"></script>  -->
<script src="https://rpo.kz/style/js/jquery.slickforms.js"></script>
<script src="https://rpo.kz/style/js/instafeed.min.js"></script>
<script src="https://rpo.kz/style/js/retina.js"></script>
<script src="https://rpo.kz/style/js/google-code-prettify/prettify.js"></script>
<script src="https://rpo.kz/style/js/scripts.js"></script>
<link rel="stylesheet" href="../nstyle.css">
<!-- Yandex.Metrika counter -->
