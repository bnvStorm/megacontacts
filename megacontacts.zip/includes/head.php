<head>
<meta charset="utf-8">
<meta http-equiv="Last-Modified" content="Mon, 11 May 2020 06:47:28 GMT">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="shortcut icon" href="../300.ico">

 <!-- social -->
<!-- <meta property="og:title" content="Промотход Сервис">
<meta property="og:type" content="article">
<meta property="og:url" content="https://rpo.kz/"> -->
<!-- <meta property="og:image" content="https://rpo.kz/style/images/social.jpg"> -->
<!-- <meta property="og:site_name" content="Промотход Сервис"> -->
<!-- <meta property="fb:admins" content="">  -->
<!-- <meta property="og:description" content="Экологичные контейнерные площадки для вашего бизнеса"> -->
<meta property="og:locale" content="ru_RU">

<!-- <meta name="twitter:card" content="summary_large_image"> -->
<!-- <meta name="twitter:site" content="@Freepik_Vectors">
<meta name="twitter:creator" content="@Freepik_Vectors"> -->
<!-- <meta name="twitter:title" content="Промотход Сервис">
<meta name="twitter:image:src" content="https://rpo.kz/style/images/social.jpg">
<meta name="twitter:url" content="https://rpo.kz/"> -->
<!-- <meta name="twitter:description" content="Экологичные контейнерные площадки для вашего бизнеса"> -->
  <!-- social -->
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
      <script src="style/js/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
      <![endif]-->
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
