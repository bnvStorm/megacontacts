jQuery(document).ready(function($) {
	$.magnificPopup.open({
  items: {
    src: '<div class="white-popup">ТОО «Казахстанский оператор по управлению отходами» информирует вас, что с 20 ноября 2020 года наша компания перешла на электронно-цифровой документооборот.<br>Акты выполненных работ выставляются на портале <a target="_blank" class="phone" href="https://esf.gov.kz/" style="text-decoration:underline;">https://esf.gov.kz/</a><br> Сообщите об этом своему бухгалтеру.<br>Акты выполненных работ (временно), акты приема-передачи, паспорта утилизации и пр. документы – на платформе <a class="phone" style="text-decoration:underline;" href="IDocs.kz">IDocs.kz</a>.<br>Благодарим вас за пользование услугами нашей компании и уверены в долгосрочном взаимовыгодном сотрудничестве!<br>По вопросам перехода на электронно-цифровой документооборот звоните по телефону <br><a class="phone" href="tel:+77058616492">8-705-861-64-92</a>.</div>', // can be a HTML string, jQuery object, or CSS selector
    type: 'inline'
  }
});
});
